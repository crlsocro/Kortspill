﻿using System;

namespace cardGame
{

	public class deck(){

	string[] players = { "Hagen", "Håkon", "Chris" };

		public void startGame()
		{

		}
	}
}
