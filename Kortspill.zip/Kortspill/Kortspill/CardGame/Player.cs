﻿
using System;
using System.Collections.Generic;

//The player class
public class Player
{
    public List<Card> Hand = new List<Card>();
    public bool HasJoker = false;
    public string name;
}
    

